// Game variables
const boardSize = 100;
const ladders = { 4: 14, 9: 31, 20: 38, 28: 84, 40: 59, 51: 67, 63: 81, 71: 91 };
const snakes = { 17: 7, 54: 34, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 99: 78 };
let currentPlayer = 1;
let positions = [0, 0];
let winner = null;

// Create board
const board = document.getElementById("board");
for (let i = boardSize; i > 0; i--) {
    const square = document.createElement("div");
    square.classList.add("square");
    square.id = `square-${i}`;
    square.textContent = i;
    if (ladders[i]) square.classList.add("ladder");
    if (snakes[i]) square.classList.add("snake");
    board.appendChild(square);
}

// Dice roll animation
function animateDice(roll) {
    const diceElement = document.getElementById("dice-animation");
    diceElement.classList.add("animate");
    diceElement.textContent = roll;
    setTimeout(() => diceElement.classList.remove("animate"), 1000);
}

// Roll Dice
document.getElementById("rollDice").addEventListener("click", () => {
    if (winner) return;

    const diceRoll = Math.floor(Math.random() * 6) + 1;
    animateDice(diceRoll);
    document.getElementById("message").textContent = `Player ${currentPlayer} rolled a ${diceRoll}`;
    
    setTimeout(() => {
        movePlayer(currentPlayer, diceRoll);
        checkWinner();
        currentPlayer = currentPlayer === 1 ? 2 : 1;
    }, 1000);  // Delay to sync with dice animation
});

// Move player function
function movePlayer(player, roll) {
    let newPosition = positions[player - 1] + roll;
    if (newPosition > boardSize) {
        newPosition = positions[player - 1];
    } else {
        if (ladders[newPosition]) {
            newPosition = ladders[newPosition];
            document.getElementById("message").textContent = `Player ${player} took a ladder to ${newPosition}`;
        } else if (snakes[newPosition]) {
            newPosition = snakes[newPosition];
            document.getElementById("message").textContent = `Player ${player} got bitten by a snake to ${newPosition}`;
        }
    }

    positions[player - 1] = newPosition;
    updateBoard();
}

// Update board display
function updateBoard() {
    document.querySelectorAll(".player").forEach(el => el.remove());
    
    for (let i = 1; i <= 2; i++) {
        const player = document.createElement("div");
        player.classList.add("player");
        player.id = `player${i}`;
        const currentSquare = document.getElementById(`square-${positions[i - 1]}`);
        if (currentSquare) currentSquare.appendChild(player);
    }
}

// Check for winner
function checkWinner() {
    if (positions[0] === boardSize) {
        document.getElementById("winner").textContent = "Player 1 Wins!";
        winner = 1;
    } else if (positions[1] === boardSize) {
        document.getElementById("winner").textContent = "Player 2 Wins!";
        winner = 2;
    }
}

// Restart Game
document.getElementById("restart").addEventListener("click", () => {
    positions = [0, 0];
    winner = null;
    currentPlayer = 1;
    document.getElementById("message").textContent = "";
    document.getElementById("winner").textContent = "";
    updateBoard();
});

// Initialize board with players at start
updateBoard();
